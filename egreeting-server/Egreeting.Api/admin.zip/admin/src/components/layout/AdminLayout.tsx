// src/components/layout/AdminLayout.tsx
import React, { useState } from 'react';
import { Container } from 'react-bootstrap';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Topbar from './Topbar';

const AdminLayout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="d-flex">
      <Sidebar sidebarOpen={sidebarOpen} />

      <div className="flex-grow-1">
        <Topbar sidebarOpen={sidebarOpen} toggleSidebar={() => setSidebarOpen(!sidebarOpen)} />

        <Container
          fluid
          className="pt-5 content-area"
          style={{
            marginLeft: sidebarOpen ? '250px' : '80px',
            transition: 'margin-left 0.3s ease',
            minHeight: '100vh',
          }}
        >
          <div className="p-4">
            <Outlet /> {/* Child pages (Dashboard, Users, etc.) render here */}
          </div>
        </Container>
      </div>
    </div>
  );
};

export default AdminLayout;