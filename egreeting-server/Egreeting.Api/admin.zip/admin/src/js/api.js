
export async function apiGet(url) {
    const token = localStorage.getItem("token");

    const res = await fetch("http://localhost:5288/" + url, {
        headers: {
            "Authorization": "Bearer " + token
        }
    });

    if (!res.ok) {
        const err = await res.text();
        throw new Error(`HTTP ${res.status}: ${err}`);
    }

    const text = await res.text();
    return text ? JSON.parse(text) : null;
}

// POST
export async function apiPost(url, data) {
    const token = localStorage.getItem("token");

    const res = await fetch("http://localhost:5288/" + url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify(data)
    });

    if (!res.ok) {
        const err = await res.text();
        throw new Error(`HTTP ${res.status}: ${err}`);
    }

    const text = await res.text();
    return text ? JSON.parse(text) : { success: true };
}

// PUT
export async function apiPut(url, data) {
    const token = localStorage.getItem("token");

    const res = await fetch("http://localhost:5288/" + url, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify(data)
    });

    if (!res.ok) {
        const err = await res.text();
        throw new Error(`HTTP ${res.status}: ${err}`);
    }

    const text = await res.text();
    return text ? JSON.parse(text) : { success: true };
}

// DELETE
export async function apiDelete(url) {
    const token = localStorage.getItem("token");

    const res = await fetch("http://localhost:5288/" + url, {
        method: "DELETE",
        headers: {
            "Authorization": "Bearer " + token
        }
    });

    if (!res.ok) {
        const err = await res.text();
        throw new Error(`HTTP ${res.status}: ${err}`);
    }

    const text = await res.text();
    return text ? JSON.parse(text) : { success: true };
}

// LOGIN
export async function login(email, password) {
    const res = await fetch("http://localhost:5288/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    });

    return res.json();
}

// ROLE
export function checkAdmin() {
    const role = localStorage.getItem("role");
    return role && role.toLowerCase() === "admin";
}

// LOGOUT
export function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    window.location.href = "/layout/login.html";
}

// COUNT API
export async function getCount(entity) {
    const token = localStorage.getItem("token");

    const res = await fetch(`http://localhost:5288/api/${entity}/count`, {
        headers: { "Authorization": "Bearer " + token }
    });

    return res.json();
}

// LOAD DASHBOARD COUNTS
async function loadDashboardCounts() {
    document.getElementById("userCount").textContent = (await getCount("users")).total;
    document.getElementById("categoryCount").textContent = (await getCount("categories")).total;
    document.getElementById("templateCount").textContent = (await getCount("templates")).total;
    document.getElementById("transactionCount").textContent = (await getCount("transactions")).total;
    document.getElementById("packageCount").textContent = (await getCount("packages")).total;
    document.getElementById("subscriptionCount").textContent = (await getCount("subscriptions")).total;
    document.getElementById("feedbackCount").textContent = (await getCount("feedbacks")).total;
    document.getElementById("reportCount").textContent = (await getCount("reports")).total;
}

loadDashboardCounts();
