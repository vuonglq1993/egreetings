// src/pages/Categories/index.tsx
import React, { useEffect, useState } from 'react';
import { Table, Button, Modal, Form, Spinner, Alert } from 'react-bootstrap';
import { apiGet, apiPost, apiPut, apiDelete } from '../../lib/api';
interface Category {
  id: number;
  name: string;
  description: string | null;
}

const CategoriesPage: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Modal state
  const [showModal, setShowModal] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [currentId, setCurrentId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ name: '', description: '' });
  const [saving, setSaving] = useState(false);

  // Load categories
  const loadCategories = async () => {
    try {
      setLoading(true);
      setError(null);
      const data: Category[] = await apiGet('api/category');
      setCategories(Array.isArray(data) ? data : []);
    } catch (err: any) {
      setError(err.message || 'Failed to load categories');
      console.error('Load categories error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCategories();
  }, []);

  // Open modal for Add / Edit
  const openAddModal = () => {
    setIsEdit(false);
    setCurrentId(null);
    setFormData({ name: '', description: '' });
    setShowModal(true);
  };

  const openEditModal = (cat: Category) => {
    setIsEdit(true);
    setCurrentId(cat.id);
    setFormData({ name: cat.name, description: cat.description || '' });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setSaving(false);
  };

  // Save category
  const saveCategory = async () => {
    if (!formData.name.trim()) {
      alert('Please enter a category name');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        id: currentId || 0,
        name: formData.name.trim(),
        description: formData.description.trim() || null,
      };

      if (isEdit && currentId) {
        await apiPut(`api/category/${currentId}`, payload);
        alert('Category updated successfully!');
      } else {
        await apiPost('api/category', payload);
        alert('Category added successfully!');
      }

      closeModal();
      loadCategories();
    } catch (err: any) {
      console.error('Save error:', err);
      alert('Error: ' + (err.message || 'Could not save category'));
    } finally {
      setSaving(false);
    }
  };

  // Delete category
  const deleteCategory = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this category?')) return;

    try {
      await apiDelete(`api/category/${id}`);
      alert('Category deleted successfully!');
      loadCategories();
    } catch (err: any) {
      console.error('Delete error:', err);
      alert('Error: ' + (err.message || 'Could not delete category'));
    }
  };

  return (
    <>
      {/* Page Header */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Categories Management</h2>
        <Button variant="primary" onClick={openAddModal}>
          <i className="bi bi-plus-circle me-2"></i>
          Add New Category
        </Button>
      </div>

      {/* Error Alert */}
      {error && <Alert variant="danger">{error}</Alert>}

      {/* Table */}
      {loading ? (
        <div className="text-center py-5">
          <Spinner animation="border" variant="primary" />
        </div>
      ) : categories.length === 0 ? (
        <Alert variant="info">No categories found. Click "Add New Category" to create one.</Alert>
      ) : (
        <Table striped hover responsive className="table-align-middle">
          <thead className="table-light">
            <tr>
              <th width="80">#</th>
              <th>ID</th>
              <th>Name</th>
              <th>Description</th>
              <th width="160" className="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((cat, index) => (
              <tr key={cat.id}>
                <td>{index + 1}</td>
                <td>{cat.id}</td>
                <td><strong>{cat.name}</strong></td>
                <td className="text-muted">{cat.description || '—'}</td>
                <td className="text-center">
                  <Button
                    size="sm"
                    variant="outline-primary"
                    className="me-2"
                    onClick={() => openEditModal(cat)}
                  >
                    <i className="bi bi-pencil"></i> Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="outline-danger"
                    onClick={() => deleteCategory(cat.id)}
                  >
                    <i className="bi bi-trash"></i> Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      {/* Add / Edit Modal */}
      <Modal show={showModal} onHide={closeModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>{isEdit ? 'Edit Category' : 'Add New Category'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Name <span className="text-danger">*</span></Form.Label>
              <Form.Control
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Enter category name"
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Optional description"
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeModal} disabled={saving}>
            Cancel
          </Button>
          <Button variant="primary" onClick={saveCategory} disabled={saving}>
            {saving ? (
              <>
                <Spinner animation="border" size="sm" className="me-2" />
                Saving...
              </>
            ) : (
              'Save Category'
            )}
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default CategoriesPage;